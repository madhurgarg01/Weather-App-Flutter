const openWeatherMapKey = 'c911bed26700596f827343eb97df72cb';
